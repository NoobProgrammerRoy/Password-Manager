import random
import string
import sqlite3

conn = sqlite3.connect('PasswordManager.db')
conn.execute('CREATE TABLE IF NOT EXISTS PASSWORDS(APP text , PASSWORD text)')

def generatePassword(app_name,length):
    password = ''
    for i in range(length):
        x = random.randint(0,94)
        password += string.printable[x]
    try:
        conn.execute('INSERT INTO PASSWORDS(APP,PASSWORD) VALUES(?,?)',(app_name,password))
        conn.commit()
        return password
    except:
        print('An error occured')

def getPassword(app_name):
    try:
        cursor = conn.execute('SELECT APP,PASSWORD FROM PASSWORDS WHERE APP = ?',(app_name,))
        for row in cursor:
            print('\nApplication/Website :', row[0])
            print('Password :', row[1])
    except:
        print('An error occured')

def listPassword():
    try:
        cursor = conn.execute('SELECT APP,PASSWORD FROM PASSWORDS')
        for row in cursor:
            print('\nApplication/Website :',row[0])
            print('Password :',row[1])
    except:
        print('An error occured')

def deletePassword(app_name):
    try:
        conn.execute('DELETE FROM PASSWORDS WHERE APP = ?',(app_name,))
        conn.commit()
        print('Record successfully deleted')
    except:
        print('An error occured')

print('****Password Manager****')
choice = int(input('\n1.Generate Password\n2.Get Password\n3.List Passwords\n4.Delete Password\n5.Exit\n'))

while choice != 5:
    if choice == 1:
        app = input('\nEnter application/website name : ')
        len = int(input('Enter the length of the password : '))
        password = generatePassword(app,len)
        print('\nApplication/Website :',app)
        print('Password :',password)
        
    elif choice == 2:
        app = input('\nEnter application/website name : ')
        getPassword(app)
        
    elif choice == 3:
        listPassword()

    elif choice == 4:
        app = input('\nEnter application/website name : ')
        deletePassword(app)
        
    choice = int(input('\n1.Generate Password\n2.Get Password\n3.List Passwords\n4.Delete Password\n5.Exit\n'))

conn.close()